 (content copied from original TODO.md)

You are Cursor acting as a meticulous refactor assistant for the Local Video Server repository.

MANDATES (from product owner):

- Keep dark mode. Remove glassmorphism and neomorphism everywhere.
- Remove VR mode and any VR/WebXR/device-detection branches; rely on the browser on Quest 2.
- Use ONE shared video player on all pages with ±10 seconds skip (buttons + keyboard).
- Keep pages: Home, Watch, Random, Best-of, Favorites, Tags, Tag videos.
- Reduce duplication and delete dead assets/docs.

[content truncated]

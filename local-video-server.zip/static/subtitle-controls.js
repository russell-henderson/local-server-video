// subtitle-controls.js — subtitle system removed; keep as noop for compatibility
/* No-op: subtitles removed. */
// Intentionally empty.
# Subtitle Generation System - Implementation Complete ✅
# Subtitle Generation System — REMOVED

The automatic subtitle generation system has been removed from this
repository. The implementation (AI transcription, CLI tools, API
endpoints, and frontend controls) was intentionally taken out. If you
need historical documentation or wish to restore the feature, please
look in `docs/deferred/` for archived notes and guides.

For safety and compatibility the application now contains small
compatibility stubs so that any remaining imports do not raise
ImportError; but the feature is not functional.
- **Model Management**: Automatic model downloading and caching

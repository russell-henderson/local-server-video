#!/usr/bin/env python3
# test_subtitles.py - Test the subtitle generation system

import os
import sys
from pathlib import Path

# Add the current directory to Python path
sys.path.insert(0, str(Path(__file__).parent))

from config_subtitles import SUBTITLES
from subtitles import has_any_subs, iter_video_files

def test_subtitle_config():
    """Test the subtitle configuration."""
    print("🔧 Testing Subtitle Configuration:")
    print(f"  Model Size: {SUBTITLES.model_size}")
    print(f"  Compute Type: {SUBTITLES.compute_type}")
    print(f"  Output Formats: {SUBTITLES.out_format}")
    print(f"  Videos Root: {SUBTITLES.videos_root}")
    print(f"  Quiet Hours: {SUBTITLES.quiet_hours}")
    print(f"  Language: {SUBTITLES.language}")
    print(f"  Translate to English: {SUBTITLES.translate_to_english}")
    print()

def test_video_discovery():
    """Test video file discovery."""
    print("🎬 Testing Video Discovery:")
    videos_dir = SUBTITLES.videos_root
    
    if not os.path.exists(videos_dir):
        print(f"  ❌ Videos directory '{videos_dir}' does not exist")
        return
    
    video_files = list(iter_video_files(videos_dir))
    print(f"  📹 Found {len(video_files)} video files")
    
    if video_files:
        print("  First 5 videos:")
        for i, video in enumerate(video_files[:5]):
            has_subs = has_any_subs(video)
            status = "✅ Has subs" if has_subs else "❌ No subs"
            filename = os.path.basename(video)
            print(f"    {i+1}. {filename} - {status}")
    print()

def test_subtitle_status():
    """Test subtitle status checking."""
    print("📝 Testing Subtitle Status:")
    videos_dir = SUBTITLES.videos_root
    
    if not os.path.exists(videos_dir):
        print(f"  ❌ Videos directory '{videos_dir}' does not exist")
        return
    
    video_files = list(iter_video_files(videos_dir))
    
    with_subs = sum(1 for v in video_files if has_any_subs(v))
    without_subs = len(video_files) - with_subs
    
    print(f"  📊 Subtitle Statistics:")
    print(f"    Total videos: {len(video_files)}")
    print(f"    With subtitles: {with_subs}")
    print(f"    Without subtitles: {without_subs}")
    
    if without_subs > 0:
        coverage = (with_subs / len(video_files)) * 100
        print(f"    Coverage: {coverage:.1f}%")
    print()

def main():
    """Run all subtitle tests."""
    print("🧪 Subtitle Generation System Test\n")
    
    try:
        test_subtitle_config()
        test_video_discovery()
        test_subtitle_status()
        
        print("✅ All tests completed successfully!")
        
    except Exception as e:
        print(f"❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()